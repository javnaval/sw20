
<img id="img" src="server/images/soundayfondonegro.png" alt="Logo y titulo de la página">
<a href='vistaLogin.php' placeholder="Iniciar sesión">Iniciar sesión</a>
<a href='vistaSignIn.php' placeholder="Registrarse">Registrarse</a>

