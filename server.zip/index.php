<?php
require_once 'includes/config.php';
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<link rel="stylesheet" type="text/css" href="css/estilo.css" />
	<meta charset="UTF-8">
	<title>Inicio</title>
</head>

<body>

	<header>
        <?php
        require 'includes/handlers/cabecera.php';
        ?>
	</header>

</body>
</html>
