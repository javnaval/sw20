# sw2kSounday
Proyecto Sistemas Web Año 2019/2020
Para que el proyecto funcione hay que crearse:
-- Usuario con todos los privilegios: 'sounday'
-- Constraseña: sounday2020
Además, marcar la opcion de crear base de datos con el mismo nombre y asi ese usuario puede tener todos los privilegios
-- Base de datos: 'sounday'