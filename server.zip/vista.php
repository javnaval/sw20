<?php 
include("includes/handlers/includedFiles.php"); 
?>
<script>openPage("vistaInicio.php");</script>